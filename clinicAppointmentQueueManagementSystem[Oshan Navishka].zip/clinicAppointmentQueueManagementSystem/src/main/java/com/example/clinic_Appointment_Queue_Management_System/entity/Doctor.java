package com.example.clinic_Appointment_Queue_Management_System.entity;

import com.example.clinic_Appointment_Queue_Management_System.enumaration.Status;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Doctor {
    @Id
    private String doctorId;

    @OneToOne
    @JoinColumn(name = "userId", nullable = false, unique = true)
    private User  user;

    @ManyToOne
    @JoinColumn(name = "specializationId", nullable = false)
    private Specializations specializations;

    private String firstName;

    private String lastName;
    
    private String licenseNumber;

    @Column(unique = true)
    private String phoneNumber;

    @Column(length = 100)
    private String email;

    @Enumerated(EnumType.STRING)
    private Status status;

    @OneToMany(mappedBy = "doctor", cascade = CascadeType.ALL)
    private List<DoctorSchedules> doctorSchedules;

    @OneToMany(mappedBy = "doctor", cascade = CascadeType.ALL)
    private List<Appointments> appointments;
}
