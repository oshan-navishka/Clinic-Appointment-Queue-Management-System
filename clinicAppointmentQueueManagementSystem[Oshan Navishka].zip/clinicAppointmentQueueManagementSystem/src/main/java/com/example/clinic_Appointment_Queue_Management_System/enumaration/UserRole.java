package com.example.clinic_Appointment_Queue_Management_System.enumaration;

public enum UserRole {
    SUPER_ADMIN,
    ADMIN,
    DOCTOR,
    PATIENT
}
